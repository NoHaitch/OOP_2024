public class Stick extends Material {
    public void use() {
        System.out.println("Menggunakan stick");
    }
}