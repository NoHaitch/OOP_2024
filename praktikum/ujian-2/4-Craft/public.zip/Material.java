public abstract class Material {
    public abstract void use();
}
