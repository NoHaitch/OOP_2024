public class Sword extends Weapon {
    
    public Sword(int damage) {
    }

    /**
     * Print dengan format "Mengayun sword", panggil method parent setelahnya
     */
    public void attack() {

    }
}