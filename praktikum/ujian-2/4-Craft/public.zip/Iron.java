public class Iron extends Material {
    public void use(){
        System.out.println("Menggunakan iron");
    }
}
