public class Axe extends Weapon{

    public Axe(int damage) {
    }

    /**
     * Print dengan format "Mengayun axe", panggil method parent setelahnya
     */
    public void attack() {
      
    }
}
