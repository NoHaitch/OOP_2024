public interface Kelas {
    public void serang(Karakter self, Karakter target);
    public void gunakanKemampuan(Karakter self, Karakter target);
    public void gunakanUltimate(Karakter self, Karakter target);
}
